#include "task1.1.h"
#include "task1_3.h"

int main(int argc, char *argv[]) {
    task1_1(argc, argv);
    return 0;
}
