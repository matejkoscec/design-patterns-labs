#ifndef C_TASKS_MYFACTORY_H
#define C_TASKS_MYFACTORY_H

#ifdef __cplusplus
extern "C" {
#endif

void* myfactory(char const* libname, char const* ctorarg);

#ifdef __cplusplus
}
#endif


#endif //C_TASKS_MYFACTORY_H
