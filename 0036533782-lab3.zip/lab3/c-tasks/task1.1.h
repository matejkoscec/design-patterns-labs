#ifndef C_TASKS_TASK1_1_H
#define C_TASKS_TASK1_1_H

#ifdef __cplusplus
extern "C" {
#endif

void task1_1(int argc, char *argv[]);

#ifdef __cplusplus
}
#endif

#endif //C_TASKS_TASK1_1_H
