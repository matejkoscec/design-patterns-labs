#ifndef C_TASKS_TASK1_3_H
#define C_TASKS_TASK1_3_H

void task1_3();

#endif //C_TASKS_TASK1_3_H
