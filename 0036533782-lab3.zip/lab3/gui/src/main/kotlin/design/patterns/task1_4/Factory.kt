package design.patterns.task1_4

fun main() {
    FactoryPattern.run()
}
