class Parrot:

    def __init__(self, name) -> None:
        self.animalName = name

    def name(self) -> str:
        return self.animalName

    def greet(self) -> str:
        return "Sto mu gromova"

    def menu(self) -> str:
        return "brazilske orahe"
