class Tiger:

    def __init__(self, name) -> None:
        self.animalName = name

    def name(self) -> str:
        return self.animalName

    def greet(self) -> str:
        return "Mijau"

    def menu(self) -> str:
        return "mlako mlijeko"
