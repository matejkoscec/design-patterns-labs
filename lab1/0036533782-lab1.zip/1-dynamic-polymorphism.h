#ifndef LAB1_1_DYNAMIC_POLYMORPHISM_H
#define LAB1_1_DYNAMIC_POLYMORPHISM_H

#ifdef __cplusplus
extern "C" {
#endif

void task1();

#ifdef __cplusplus
}
#endif

#endif //LAB1_1_DYNAMIC_POLYMORPHISM_H