#ifndef LAB1_2C_VIRTUAL_TABLES_H
#define LAB1_2C_VIRTUAL_TABLES_H

#ifdef __cplusplus
extern "C" {
#endif

void task2c();

#ifdef __cplusplus
}
#endif

#endif //LAB1_2C_VIRTUAL_TABLES_H
