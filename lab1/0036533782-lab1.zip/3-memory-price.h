#ifndef LAB1_3_MEMORY_PRICE_H
#define LAB1_3_MEMORY_PRICE_H

void task3();

#endif //LAB1_3_MEMORY_PRICE_H
