#ifndef LAB1_4_TIME_PRICE_H
#define LAB1_4_TIME_PRICE_H

void task4();

#endif //LAB1_4_TIME_PRICE_H
