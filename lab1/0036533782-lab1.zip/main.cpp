#include "1-dynamic-polymorphism.h"
#include "2-virtual-tables.h"
#include "2c-virtual-tables.h"
#include "3-memory-price.h"
#include "4-time-price.h"
#include "5-manual-vtable-call.h"
#include "6-polimorphism-while-constructing.h"

int main() {
//    task1();
//    task2();
//    task2c();
//    task3();
//    task4();
//    task5();
    task6();

    return 0;
}
